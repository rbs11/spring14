#include "rvm.h"
#include "rvm_internal.h"
#include <stdio.h>
#include <stddef.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

RVM_Metadata_t *gRVMMetadata;
Transactions_t *gTransList;
rvm_t g_rvmID = 0;

#define DEBUG

#ifdef DEBUG
#define	print_dbg(fmt, arg...) 					\
do {											\
	printf(fmt, ## arg);					\
	printf("\n");							\
} while (0);
#else
#define	print_dbg(fmt, arg...)
#endif

rvm_t rvm_init(const char *directory)
{
	struct stat dirstats;
	int32_t errno;
	if (!stat(directory, &dirstats)) {
		print_dbg("Directory Already Exists");
		return g_rvmID;
	}

	gRVMMetadata = (RVM_Metadata_t*)malloc(sizeof(RVM_Metadata_t));
	gRVMMetadata->DirName = strdup(directory);
	if (errno=mkdir(directory, 777)){
		printf("Error[%d] while creating Directory\n");
	}
	gRVMMetadata->RVM_Id = ++g_rvmID;
	if (g_rvmID > 1){
		printf("Init being called more than once. This condition is not required to be handled.\n");
		return -1;
	}

	return gRVMMetadata->RVM_Id ;

}

void *rvm_map(rvm_t rvm, const char *segname, int size_to_create)
{
	bool bSegNotFound;
	FILE* fd;
	if (gRVMMetadata->RVM_Id != rvm){
		printf("Invalid RVM for this request\n");
		return NULL;
	}
	/*Check if segment already exists on disk*/

	/*If so, check if size is the same as of that requested*/

	/*If not create a fresh segment on disk and map it to memory*/
	if (bSegNotFound){
		char segpath[100];
		sprintf(segpath, gRVMMetadata->DirName, "/",segname);
		print_dbg("Creating file under path %s", segpath);
	}

}

void rvm_unmap(rvm_t rvm, void *segbase)
{

}

void rvm_destroy(rvm_t rvm, const char *segname)
{

}

trans_t rvm_begin_trans(rvm_t rvm, int numsegs, void **segbases)
{

}

void rvm_about_to_modify(trans_t tid, void *segbase, int offset, int size)
{

}

void rvm_commit_trans(trans_t tid)
{

}

void rvm_abort_trans(trans_t tid)
{

}

void rvm_truncate_log(rvm_t rvm)
{

}
