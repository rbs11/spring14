#include <stdio.h>
#include <mpi.h>

//#define DEBUG
#ifdef DEBUG
#define	print_dbg(fmt, arg...) 	printf(fmt, ## arg)
#else
#define	print_dbg(fmt, arg...)
#endif

void sensereverse_barrier(int *my_id, int *num_processes, int *sense, int *local_sense)
{
	int bufval = 1, i;
	*local_sense = !(*local_sense);
	if (*my_id != 0){ //not a root process, send a message to root indicating arrival at barrier
		print_dbg("process %d Sending message\n", *my_id);
		bufval = *my_id;
		MPI_Send( &bufval, 1, MPI_INT, 0, 1 , MPI_COMM_WORLD );
		/*print_dbg("process %d waiting for root\n", *my_id);
		MPI_Recv( sense, 1 ,MPI_INT, 0, 1, MPI_COMM_WORLD, NULL );*/
		print_dbg("process %d reached with sense %d\n", *my_id, *sense);
	}
	else{
		for (i = 1; i < *num_processes; i++){
			MPI_Recv( &bufval, 1 ,MPI_INT, i, 1, MPI_COMM_WORLD, NULL );
			print_dbg("Received Process %d message --%d\n", i, bufval);
		}
		/*All have completed*/
		*sense = !(*sense);
		/*for (i = 1; i < *num_processes; i++){
			MPI_Ssend( sense, 1 ,MPI_INT, i, 1, MPI_COMM_WORLD);
			print_dbg("Sent Sense to Process %d message --%d\n", i, sense);
		}*/
	}

	do{
		print_dbg("process %d ongoing with sense %d\n", *my_id, *sense);
		MPI_Bcast(sense, 1, MPI_INT, 0, MPI_COMM_WORLD);
		*local_sense = *sense;
		print_dbg("process %d broadcast with sense %d\n", *my_id, *sense);
	}while(0); //local_sense == *sense
}
int main(int argc, char **argv)
{
  int my_id, num_processes, i;
  double tstart, tend, tfinal;
  int sense = 0, local_sense = 0;

  MPI_Init(&argc, &argv);

  MPI_Comm_size(MPI_COMM_WORLD, &num_processes);
  MPI_Comm_rank(MPI_COMM_WORLD, &my_id);

  print_dbg("Hello World from processes %d of %d\n", my_id, num_processes);
  local_sense = sense;
  for( i=0; i<2; i++ ){
  tstart = MPI_Wtime();
  sensereverse_barrier(&my_id, &num_processes, &sense, &local_sense);
 // MPI_Barrier(MPI_COMM_WORLD);
  tfinal = MPI_Wtime();
  printf("process %d completed barrier [%d] time [%f]\n", my_id, i, (tfinal - tstart));
  }
  MPI_Finalize();
  return 0;
}

