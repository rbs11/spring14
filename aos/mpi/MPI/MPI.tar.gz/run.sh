mpirun -mca btl tcp,self --hostfile mpd.hosts $1
