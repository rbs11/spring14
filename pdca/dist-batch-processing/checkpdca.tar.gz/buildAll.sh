#!/bin/bash
./buildCommon.sh
./buildScheduler.sh
./buildWorker.sh
./buildJobs.sh
./buildClient.sh
